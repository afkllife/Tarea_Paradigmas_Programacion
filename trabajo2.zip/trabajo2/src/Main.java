import frontend.vista.PantallaInicio;
import frontend.controlador.ControladorInicio;

public class Main {
    public static void main(String[] args) {
        PantallaInicio inicio = new PantallaInicio();
        ControladorInicio controlador = new ControladorInicio(inicio);
        inicio.setControladorCargarArchivo(controlador);
        inicio.setVisible(true);
    }
}