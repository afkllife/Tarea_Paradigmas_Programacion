package backend.servicios;

import backend.modelo.*;

import java.util.*;

public class ResultadoResumen {
    private Map<NivelBloom, Integer> correctasPorNivel = new EnumMap<>(NivelBloom.class);
    private Map<TipoItem, Integer> correctasPorTipo = new EnumMap<>(TipoItem.class);

    public ResultadoResumen(List<Item> items, List<String> respuestas) {
        for (int i = 0; i < items.size(); i++) {
            Item item = items.get(i);
            String resp = respuestas.get(i);
            boolean correcta = resp != null && item.esCorrecta(resp);

            if (correcta) {
                correctasPorNivel.merge(item.getNivel(), 1, Integer::sum);
                correctasPorTipo.merge(item.getTipo(), 1, Integer::sum);
            }
        }
    }

    public Map<NivelBloom, Integer> getCorrectasPorNivel() { return correctasPorNivel; }
    public Map<TipoItem, Integer> getCorrectasPorTipo() { return correctasPorTipo; }
}
