package backend.servicios;

import backend.modelo.*;

import java.util.ArrayList;
import java.util.List;

public class GestorPrueba {
    private List<Item> items;
    private List<String> respuestasUsuario;
    private int indiceActual;

    public GestorPrueba(List<Item> items) {
        this.items = items;
        this.respuestasUsuario = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) respuestasUsuario.add(null);
        this.indiceActual = 0;
    }

    public Item getItemActual() { return items.get(indiceActual); }
    public int getIndiceActual() { return indiceActual; }
    public int getCantidadItems() { return items.size(); }
    public int getTiempoTotalEstimado() {
        return items.stream().mapToInt(i -> i.getTiempoEstimado()).sum();
    }

    // Añade este método:
    public List<Item> getItems() {
        return items;
    }

    public void avanzar() { if (indiceActual < items.size() - 1) indiceActual++; }
    public void retroceder() { if (indiceActual > 0) indiceActual--; }
    public void registrarRespuesta(String respuesta) { respuestasUsuario.set(indiceActual, respuesta); }
    public String getRespuesta(int indice) { return respuestasUsuario.get(indice); }

    public ResultadoResumen obtenerResumen() {
        return new ResultadoResumen(items, respuestasUsuario);
    }
}