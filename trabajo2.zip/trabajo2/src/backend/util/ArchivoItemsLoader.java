package backend.util;

import backend.modelo.*;

import java.io.*;
import java.util.*;

public class ArchivoItemsLoader {
    public static List<Item> cargarDesdeArchivo(File archivo) throws Exception {
        List<Item> items = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length < 5) throw new Exception("Formato incorrecto: " + linea);

                String tipo = partes[0].trim(); // MULTIPLE o VF
                String enunciado = partes[1].trim();
                String nivelStr = partes[2].trim().toUpperCase();
                int tiempo = Integer.parseInt(partes[3].trim());

                NivelBloom nivel = NivelBloom.valueOf(nivelStr);

                if (tipo.equalsIgnoreCase("MULTIPLE")) {
                    List<String> opciones = Arrays.asList(partes[4].split("\\|"));
                    int indiceCorrecto = Integer.parseInt(partes[5].trim());
                    items.add(new ItemMultiple(enunciado, opciones, indiceCorrecto, nivel, tiempo));
                } else if (tipo.equalsIgnoreCase("VF")) {
                    boolean respuestaCorrecta = Boolean.parseBoolean(partes[4].trim());
                    items.add(new ItemVF(enunciado, respuestaCorrecta, nivel, tiempo));
                } else {
                    throw new Exception("Tipo de ítem desconocido: " + tipo);
                }
            }
        }
        return items;
    }
}
