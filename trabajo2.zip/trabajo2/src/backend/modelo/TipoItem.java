package backend.modelo;

public enum TipoItem {
    MULTIPLE, VERDADERO_FALSO
}