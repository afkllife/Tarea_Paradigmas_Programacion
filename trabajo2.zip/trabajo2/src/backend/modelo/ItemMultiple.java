package backend.modelo;

import java.util.List;

public class ItemMultiple extends Item {
    private List<String> opciones;
    private int indiceCorrecto;

    public ItemMultiple(String enunciado, List<String> opciones, int indiceCorrecto, NivelBloom nivel, int tiempoEstimado) {
        this.enunciado = enunciado;
        this.opciones = opciones;
        this.indiceCorrecto = indiceCorrecto;
        this.nivel = nivel;
        this.tipo = TipoItem.MULTIPLE;
        this.tiempoEstimado = tiempoEstimado;
    }

    public void setOpciones(List<String> opciones) {
        this.opciones = opciones;
    }

    @Override
    public boolean esCorrecta(String respuesta) {
        return opciones.get(indiceCorrecto).equalsIgnoreCase(respuesta.trim());
    }

    public List<String> getOpciones() { return opciones; }
}

