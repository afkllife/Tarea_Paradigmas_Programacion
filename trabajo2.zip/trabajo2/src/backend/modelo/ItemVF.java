package backend.modelo;

public class ItemVF extends Item {
    private boolean respuestaCorrecta;

    public ItemVF(String enunciado, boolean respuestaCorrecta, NivelBloom nivel, int tiempoEstimado) {
        this.enunciado = enunciado;
        this.respuestaCorrecta = respuestaCorrecta;
        this.nivel = nivel;
        this.tipo = TipoItem.VERDADERO_FALSO;
        this.tiempoEstimado = tiempoEstimado;
    }

    @Override
    public boolean esCorrecta(String respuesta) {
        return Boolean.parseBoolean(respuesta.trim().toLowerCase());
    }

    public boolean getRespuestaCorrecta() { return respuestaCorrecta; }
}
