package backend.modelo;

public enum NivelBloom {
    RECORDAR, ENTENDER, APLICAR, ANALIZAR, EVALUAR, CREAR
}
