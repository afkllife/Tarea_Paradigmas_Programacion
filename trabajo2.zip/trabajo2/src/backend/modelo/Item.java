package backend.modelo;

public abstract class Item {
    protected String enunciado;
    protected NivelBloom nivel;
    protected int tiempoEstimado;
    protected TipoItem tipo;

    public abstract boolean esCorrecta(String respuesta);

    public String getEnunciado() { return enunciado; }
    public NivelBloom getNivel() { return nivel; }
    public int getTiempoEstimado() { return tiempoEstimado; }
    public TipoItem getTipo() { return tipo; }
}