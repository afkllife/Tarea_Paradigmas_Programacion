package frontend.vista;

import backend.modelo.NivelBloom;
import backend.modelo.TipoItem;
import backend.servicios.GestorPrueba;
import backend.servicios.ResultadoResumen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Map;

public class PantallaResumen extends JFrame {
    private GestorPrueba gestor;

    public PantallaResumen(GestorPrueba gestor) {
        this.gestor = gestor;
        setTitle("Resumen de Resultados");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        ResultadoResumen resumen = gestor.obtenerResumen();

        JTextArea textoResumen = new JTextArea();
        textoResumen.setEditable(false);
        textoResumen.setFont(new Font("Monospaced", Font.PLAIN, 14));
        StringBuilder sb = new StringBuilder();

        sb.append("✔ Porcentaje de respuestas correctas por Nivel Bloom:\n");
        for (NivelBloom nivel : NivelBloom.values()) {
            int correctas = resumen.getCorrectasPorNivel().getOrDefault(nivel, 0);
            long total = gestor.getItems().stream().filter(i -> i.getNivel() == nivel).count();
            int porcentaje = (total == 0) ? 0 : (int) (100 * correctas / total);
            sb.append("- ").append(nivel).append(": ").append(porcentaje).append("%\n");
        }

        sb.append("\n✔ Porcentaje de respuestas correctas por Tipo de ítem:\n");
        for (TipoItem tipo : TipoItem.values()) {
            int correctas = resumen.getCorrectasPorTipo().getOrDefault(tipo, 0);
            long total = gestor.getItems().stream().filter(i -> i.getTipo() == tipo).count();
            int porcentaje = (total == 0) ? 0 : (int) (100 * correctas / total);
            sb.append("- ").append(tipo).append(": ").append(porcentaje).append("%\n");
        }

        textoResumen.setText(sb.toString());

        JButton botonRevisar = new JButton("Revisar respuestas");
        JButton botonSalir = new JButton("Salir");

        botonRevisar.addActionListener(e -> {
            PantallaRevision revision = new PantallaRevision(gestor);
            revision.setVisible(true);
            dispose();
        });

        botonSalir.addActionListener(e -> System.exit(0));

        JPanel panelBotones = new JPanel();
        panelBotones.add(botonRevisar);
        panelBotones.add(botonSalir);

        setLayout(new BorderLayout());
        add(new JScrollPane(textoResumen), BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }
}
