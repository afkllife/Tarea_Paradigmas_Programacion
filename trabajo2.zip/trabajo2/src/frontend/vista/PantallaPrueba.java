package frontend.vista;

import backend.modelo.*;
import backend.servicios.GestorPrueba;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class PantallaPrueba extends JFrame {
    private GestorPrueba gestor;

    private JLabel etiquetaPregunta;
    private JPanel panelOpciones;
    private JButton botonAnterior;
    private JButton botonSiguiente;
    private ButtonGroup grupoOpciones;

    public PantallaPrueba(GestorPrueba gestor) {
        this.gestor = gestor;

        setTitle("Aplicación de Prueba");
        setSize(600, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        etiquetaPregunta = new JLabel("", SwingConstants.CENTER);
        panelOpciones = new JPanel(new GridLayout(0, 1));
        botonAnterior = new JButton("Volver atrás");
        botonSiguiente = new JButton("Siguiente");

        JPanel panelBotones = new JPanel();
        panelBotones.add(botonAnterior);
        panelBotones.add(botonSiguiente);

        setLayout(new BorderLayout());
        add(etiquetaPregunta, BorderLayout.NORTH);
        add(panelOpciones, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        botonAnterior.addActionListener(this::accionAnterior);
        botonSiguiente.addActionListener(this::accionSiguiente);

        actualizarVista();
    }

    private void actualizarVista() {
        Item item = gestor.getItemActual();
        etiquetaPregunta.setText("<html><h3>" + item.getEnunciado() + "</h3></html>");

        panelOpciones.removeAll();
        grupoOpciones = new ButtonGroup();

        if (item instanceof ItemMultiple multiple) {
            List<String> opciones = multiple.getOpciones();
            for (String opcion : opciones) {
                JRadioButton radio = new JRadioButton(opcion);
                grupoOpciones.add(radio);
                panelOpciones.add(radio);
                if (opcion.equalsIgnoreCase(gestor.getRespuesta(gestor.getIndiceActual()))) {
                    radio.setSelected(true);
                }
            }
        } else if (item instanceof ItemVF vf) {
            JRadioButton si = new JRadioButton("Verdadero");
            JRadioButton no = new JRadioButton("Falso");
            grupoOpciones.add(si);
            grupoOpciones.add(no);
            panelOpciones.add(si);
            panelOpciones.add(no);

            String r = gestor.getRespuesta(gestor.getIndiceActual());
            if ("true".equalsIgnoreCase(r)) si.setSelected(true);
            if ("false".equalsIgnoreCase(r)) no.setSelected(true);
        }

        panelOpciones.revalidate();
        panelOpciones.repaint();

        botonAnterior.setEnabled(gestor.getIndiceActual() > 0);
        botonSiguiente.setText(gestor.getIndiceActual() == gestor.getCantidadItems() - 1 ? "Enviar respuestas" : "Siguiente");
    }

    private void accionAnterior(ActionEvent e) {
        guardarRespuestaActual();
        gestor.retroceder();
        actualizarVista();
    }

    private void accionSiguiente(ActionEvent e) {
        guardarRespuestaActual();
        if (gestor.getIndiceActual() == gestor.getCantidadItems() - 1) {
            JOptionPane.showMessageDialog(this, "¡Respuestas enviadas!");
            if (gestor.getIndiceActual() == gestor.getCantidadItems() - 1) {
                guardarRespuestaActual();
                PantallaResumen resumen = new PantallaResumen(gestor);
                resumen.setVisible(true);
                dispose();
            } else {
                gestor.avanzar();
                actualizarVista();
            }

        } else {
            gestor.avanzar();
            actualizarVista();
        }
    }

    private void guardarRespuestaActual() {
        for (AbstractButton button : java.util.Collections.list(grupoOpciones.getElements())) {
            if (button.isSelected()) {
                gestor.registrarRespuesta(button.getText());
                break;
            }
        }
    }
}
