package frontend.vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PantallaInicio extends JFrame {
    private JButton botonCargarArchivo;
    private JLabel etiquetaEstado;

    public PantallaInicio() {
        super("Sistema de Evaluación - Tarea 2");
        setSize(500, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        botonCargarArchivo = new JButton("Cargar archivo de ítems");
        etiquetaEstado = new JLabel("Esperando carga de archivo...", SwingConstants.CENTER);

        setLayout(new BorderLayout());
        add(botonCargarArchivo, BorderLayout.NORTH);
        add(etiquetaEstado, BorderLayout.CENTER);
    }

    public void setControladorCargarArchivo(ActionListener listener) {
        botonCargarArchivo.addActionListener(listener);
    }

    public void actualizarEstado(String mensaje) {
        etiquetaEstado.setText(mensaje);
    }
}
