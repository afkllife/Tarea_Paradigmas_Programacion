package frontend.vista;

import backend.modelo.*;
import backend.servicios.GestorPrueba;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PantallaRevision extends JFrame {
    private GestorPrueba gestor;
    private JLabel etiquetaPregunta;
    private JLabel etiquetaResultado;
    private JPanel panelOpciones;
    private JButton botonAnterior;
    private JButton botonSiguiente;
    private JButton botonResumen;

    public PantallaRevision(GestorPrueba gestor) {
        this.gestor = gestor;

        setTitle("Revisión de Respuestas");
        setSize(600, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        etiquetaPregunta = new JLabel("", SwingConstants.CENTER);
        etiquetaResultado = new JLabel("", SwingConstants.CENTER);
        panelOpciones = new JPanel(new GridLayout(0, 1));
        botonAnterior = new JButton("Volver atrás");
        botonSiguiente = new JButton("Siguiente");
        botonResumen = new JButton("Volver al resumen");

        JPanel panelBotones = new JPanel();
        panelBotones.add(botonAnterior);
        panelBotones.add(botonSiguiente);
        panelBotones.add(botonResumen);

        setLayout(new BorderLayout());
        add(etiquetaPregunta, BorderLayout.NORTH);
        add(panelOpciones, BorderLayout.CENTER);
        add(etiquetaResultado, BorderLayout.SOUTH);
        add(panelBotones, BorderLayout.PAGE_END);

        botonAnterior.addActionListener(e -> {
            gestor.retroceder();
            actualizarVista();
        });

        botonSiguiente.addActionListener(e -> {
            gestor.avanzar();
            actualizarVista();
        });

        botonResumen.addActionListener(e -> {
            PantallaResumen resumen = new PantallaResumen(gestor);
            resumen.setVisible(true);
            dispose();
        });

        actualizarVista();
    }

    private void actualizarVista() {
        Item item = gestor.getItemActual();
        String respuesta = gestor.getRespuesta(gestor.getIndiceActual());

        etiquetaPregunta.setText("<html><h3>" + item.getEnunciado() + "</h3></html>");
        panelOpciones.removeAll();

        if (item instanceof ItemMultiple multiple) {
            List<String> opciones = multiple.getOpciones();
            for (int i = 0; i < opciones.size(); i++) {
                String texto = opciones.get(i);
                JLabel label = new JLabel("- " + texto);
                if (texto.equalsIgnoreCase(respuesta)) {
                    label.setForeground(item.esCorrecta(texto) ? Color.GREEN : Color.RED);
                }
                panelOpciones.add(label);
            }
        } else if (item instanceof ItemVF vf) {
            String texto = respuesta != null && respuesta.equalsIgnoreCase("true") ? "Verdadero" : "Falso";
            JLabel label = new JLabel("- " + texto);
            label.setForeground(item.esCorrecta(respuesta) ? Color.GREEN : Color.RED);
            panelOpciones.add(label);
        }

        etiquetaResultado.setText(item.esCorrecta(respuesta) ? "✅ Correcto" : "❌ Incorrecto");

        botonAnterior.setEnabled(gestor.getIndiceActual() > 0);
        botonSiguiente.setEnabled(gestor.getIndiceActual() < gestor.getCantidadItems() - 1);

        panelOpciones.revalidate();
        panelOpciones.repaint();
    }
}
