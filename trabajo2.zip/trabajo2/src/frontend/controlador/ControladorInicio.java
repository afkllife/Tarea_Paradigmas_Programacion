package frontend.controlador;

import backend.modelo.Item;
import backend.util.ArchivoItemsLoader;
import backend.servicios.GestorPrueba;
import frontend.vista.PantallaInicio;
import frontend.vista.PantallaPrueba;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

public class ControladorInicio implements ActionListener {
    private PantallaInicio vista;

    public ControladorInicio(PantallaInicio vista) {
        this.vista = vista;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        int resultado = fileChooser.showOpenDialog(null);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();

            try {
                List<Item> items = ArchivoItemsLoader.cargarDesdeArchivo(archivo); // Tenés que implementarlo
                GestorPrueba gestor = new GestorPrueba(items);

                vista.actualizarEstado("Archivo cargado con " + items.size() + " ítems.");
                PantallaPrueba pantallaPrueba = new PantallaPrueba(gestor);
                pantallaPrueba.setVisible(true);
                vista.dispose(); // Esto cierra la ventana actual


            } catch (Exception ex) {
                vista.actualizarEstado("Error: " + ex.getMessage());
            }
        }
    }
}
